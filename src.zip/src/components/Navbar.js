"use client"

import { useState } from "react"

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <span className="text-2xl font-bold text-black">1WS.</span>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-8">
              <a href="#services" className="text-gray-700 hover:text-black px-3 py-2 text-sm font-medium">
                Services
              </a>
              <a href="#industries" className="text-gray-700 hover:text-black px-3 py-2 text-sm font-medium">
                Industries
              </a>
              <a href="#about" className="text-gray-700 hover:text-black px-3 py-2 text-sm font-medium">
                About
              </a>
              <a href="#blog" className="text-gray-700 hover:text-black px-3 py-2 text-sm font-medium">
                Blog and Guide
              </a>
            </div>
          </div>

          {/* Search Bar */}
          <div className="hidden md:flex items-center">
            <div className="relative">
              <input
                type="text"
                placeholder="Search products or services..."
                className="bg-gray-50 border border-gray-200 rounded-lg px-4 py-2 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent w-64"
              />
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <svg className="h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                  />
                </svg>
              </div>
            </div>
          </div>

          {/* Desktop Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="text-gray-700 hover:text-black px-4 py-2 text-sm font-medium border border-gray-300 rounded-lg">
              Sign In
            </button>
            <button className="bg-black text-white px-4 py-2 text-sm font-medium rounded-lg hover:bg-gray-800">
              Contact Us
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-700 hover:text-black focus:outline-none focus:text-black"
            >
              <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              <a href="#services" className="text-gray-700 hover:text-black block px-3 py-2 text-base font-medium">
                Services
              </a>
              <a href="#industries" className="text-gray-700 hover:text-black block px-3 py-2 text-base font-medium">
                Industries
              </a>
              <a href="#about" className="text-gray-700 hover:text-black block px-3 py-2 text-base font-medium">
                About
              </a>
              <a href="#blog" className="text-gray-700 hover:text-black block px-3 py-2 text-base font-medium">
                Blog and Guide
              </a>
              <div className="pt-4 pb-3 border-t border-gray-200">
                <button className="w-full text-left text-gray-700 hover:text-black block px-3 py-2 text-base font-medium">
                  Sign In
                </button>
                <button className="w-full mt-2 bg-black text-white px-3 py-2 text-base font-medium rounded-lg">
                  Contact Us
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}

export default Navbar
